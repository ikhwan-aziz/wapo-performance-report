# Prototype Aplikasi Pencatatan Point Teknisi Jam Tangan

Prototype aplikasi pencatatan point untuk teknisi jam tangan ini bertujuan untuk membantu "user-pencatat" melakukan pencatatan point berdasarkan pekerjaan yang dilakukan oleh teknisi jam tangan dengan memanfaat teknologi aplikasi berbasis website.

Pada repositori ini berisikan source-code prototype aplikasi pencatatan point yang dikembangkan dari master aplikasi "Book-Manager" pada sumber berikit : https://github.com/bilal0558/Books-Manager
